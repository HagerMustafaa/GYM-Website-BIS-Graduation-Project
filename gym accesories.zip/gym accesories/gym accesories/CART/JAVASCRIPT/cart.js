
let container = document.querySelector("#cart-items");
let subtotalElement = document.querySelector("#subtotal");
let totalElement = document.querySelector("#total");
let checkbtn = document.querySelector(".checkout");


function drawCartPage() {

    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let totalPrice = 0;


    container.innerHTML = "";

   
    if (cart.length === 0) {
        container.innerHTML = "<h1 class='text-center w-100' style='color: #166088;'>YOUR CART IS EMPTY</h1>";
        subtotalElement.innerHTML = "$0";
        totalElement.innerHTML = "$0";
        return;
    }

  
    cart.forEach((item, index) => {
        container.innerHTML += `
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm" style="border-radius: 15px; overflow: hidden;">
                    <img class="card-img-top" src="${item.imageUrl}" height="250px" style="object-fit: cover;" alt="${item.title}">
                    <div class="card-body" style="text-align: center;">
                        <h4 class="card-title" style="color:#166088; font-family:fantasy; margin-bottom: 10px;">${item.title}</h4>
                        <span style="background-color: #166088; padding: 5px 15px; color:white; border-radius: 5px; font-weight: bold;">${item.price}</span>
                        <p class="card-text" style="margin-top: 10px; color: #555;">${item.p || 'Product Description'}</p>
                        <button class="btn btn-danger btn-block mt-3" onClick="removeItem(${index})">
                            <i class="fas fa-trash-alt"></i> DELETE
                        </button>
                    </div>
                </div>
            </div>`;

        
        let cleanPrice = parseFloat(item.price.toString().replace(/[^\d.]/g, '')) || 0;
        totalPrice += cleanPrice;
    });

    
    let shipping = 50; 
    
    subtotalElement.innerHTML = "$" + totalPrice.toFixed(2);
    totalElement.innerHTML = "$" + (totalPrice + shipping).toFixed(2);


    localStorage.setItem("totalAmount", (totalPrice + shipping).toFixed(2));
}


window.removeItem = function(index) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(index, 1); 
    localStorage.setItem("cart", JSON.stringify(cart)); 
    drawCartPage(); 
};


if (checkbtn) {
    checkbtn.addEventListener("click", function() {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        if (cart.length > 0) {
            window.location.href = "Visa/Visa.html";
        } else {
            alert("Sorry, Cart is Empty!!");
        }
    });
}


document.addEventListener("DOMContentLoaded", drawCartPage);