let allProducts = document.querySelector("#allProducts")
let products = [
    {
        id : 1 , 
        price : 500,
        title :"SPORT BAG",
        p : "Black Duffel Bag",
        imageUrl :"images/images (1).jpeg",
    },
    {
        id : 2 , 
        price : 50,
        title :"BLACK CREW SOCK",
        p : "Gymshark black crew socks",
        imageUrl :"images/images (2).jpeg",
    },
    {
        id : 3 , 
        price : 100,
        title :"BOTTLE",
        p : "Pump Stainless Steel Shaker Bottle",
        imageUrl :"images/images (3).jpeg",
    },
    {
        id : 4 , 
        price : 150,
        title :"RESISTANCE BANDS",
        p : "Versatile bands for every workout",
        imageUrl :"images/images (4).jpeg",
    },
    {
        id : 5 , 
        price : 250,
        title :"BLACK SHOULDER BACK",
        p : "shoulder bag for everyday essentials",
        imageUrl :"images/images.jpeg",
    },
    {
        id : 6 , 
        price : 80,
        title :"LIFTING STRAP",
        p : "Durable lifting strap for stronger grip.",
        imageUrl :"images/shopping (1).webp",
    },
     {
        id : 7 , 
        price : 200,
        title :"WEIGHTLIFTING BELT",
        p : "Weightlifting belt for back support",
        imageUrl :"images/shopping (2).webp",
    },
     {
        id : 8 , 
        price : 120,
        title :"ATHLETIC SHIRT",
        p : "Performance shirt with bold design",
        imageUrl :"images/shopping (4).webp",
    },
     {
        id : 9 , 
        price : 100,
        title :"BOTTLE",
        p : "Pump Stainless Steel Shaker Bottle",
        imageUrl :"images/prod (3).avif",
    },
    {
        id : 10 , 
        price : 200,
        title :"WATCH",
        p : "Black Women Running Watch",
        imageUrl :"images/prod (4).avif",
    },
     {
        id : 11 , 
        price : 150,
        title :"STOP WATCH",
        p : "ONstart 110 Stop Watch",
        imageUrl :"images/prod (5).avif",
    },
     {
        id : 12 , 
        price : 300,
        title :"BAG",
        p : "Bag For Every Day Essenial",
        imageUrl :"images/prod (1).avif",
    },
    {
        id : 13 , 
        price : 90,
        title :" SUPPORT STRAP",
        p : "Elastic wrist wraps – secure support for heavy lifts",
        imageUrl :"images/shopping (3).webp",
    },
     {
        id : 14 , 
        price : 100,
        title :"WATER BOTTLE",
        p : "1L Inssulated Atainless Steel Bottle For Hot & Cold Drinks",
        imageUrl :"images/prod (2).avif",
    },
    {
        id : 15 , 
        price : 70,
        title :" LIFTING STRAPS",
        p : "GOUNOD Lifting Straps – Secure your grip, lift with confidence",
        imageUrl :"images/shopping.webp",
    },
]

function drawItems(){
let y = products.map((item)=>{
    return `
        <div class="col-md-4 mb-4">
        <div class="card">
            <img class="card-img-top" src="${item.imageUrl}" height="300px" alt="Card image">
            <div class="card-body" style="text-align: center;">
              <h4 class="card-title" style="color:#166088; font-family:fantasy ; margin-bottom: 10px;">${item.title}</h4>
              <span style="background-color: #166088; padding: 5px; color:white;">${item.price}</span>
              <p class="card-text" style="margin-top: 10px;">${item.p}</p>
              <a href="#" class="btn btn-primary" onClick="addToCart(event,${item.id})">ADD TO CART</a>
            </div>
          </div>
          </div>
    `
}
).join("");
 allProducts.innerHTML += y;
}
drawItems();
let badge = document.querySelector(".badge")
let count=0;
function addToCart(e,id){
    e.preventDefault();
    let cart = JSON.parse(localStorage.getItem("cart"))||[];
    let selectedItem = products.find(item => item.id === id);
    cart.push(selectedItem);
    localStorage.setItem("cart" , JSON.stringify(cart))
    count++
badge.innerHTML = count;
}